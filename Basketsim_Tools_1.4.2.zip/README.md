# Basketsim Tools 1.4.2

Standalone Chrome MV3 extension. Load the `basketsim-tools` folder from `chrome://extensions` with Developer mode enabled.

Verified calculations:

- Sponsors: `round(7000 * sqrt(fans))`; 300 fans = €121,244.
- Agents: BSGoodies day factor, fee, net sale proceeds, and net profit; €100,000 → €300,000 at 10 days = €170,000 fee and €30,000 net profit.
- Cheerleaders: `round(1.25 * capacity + 1100)`; 1,500 seats = €2,975, 16,500 seats = €21,725, 30,000 seats = €38,600.
- Arena Planner: restored compact current/target layout with BSGoodies add-only allocation, construction cost, min fans, and construction days.
- Coach & Training: not injected by this extension.

The Arena page reads Total Capacity from the original Basketsim page. The Arena Planner reads Court side capacity, Courtend capacity, Upper level capacity and Number of VIP boxes from the same shared snapshot. Existing seats are never removed; final capacity may exceed Target Capacity. The previous compact layout remains left-aligned below the page content.

All fields recalculate on input and persist locally. No server mutations or automatic transactions are performed. Live authenticated browser acceptance remains separate from the arithmetic and syntax checks.
