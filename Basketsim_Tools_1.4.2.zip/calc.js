(() => {
  const number = value => { const s=String(value??'').replace(/\u00a0/g,' ').replace(/[^0-9,.-]/g,'').trim(); if(!s)return 0; const c=s.lastIndexOf(','),d=s.lastIndexOf('.'); if(c>=0&&d>=0)return Number(c>d?s.replace(/\./g,'').replace(',','.'):s.replace(/,/g,''))||0; if(c>=0&&s.length-c-1===3)return Number(s.replace(/,/g,''))||0; return Number(s.replace(',','.'))||0; };
  const eur = value => `€${Math.round(Number(value)||0).toLocaleString('en-US')}`;
  const sponsors = fans => Math.round(7000*Math.sqrt(Math.max(0,fans)));
  const agents = (purchase,sale,days) => { const profit=sale-purchase; const factor=days>=61?0:days<=0?1:Math.round(1000*(61-days)/60)/1000; const fee=profit>0?Math.round(profit*factor):0; return {fee,proceeds:sale-fee,net:sale-purchase-fee,factor}; };
  const cheerleaders = capacity => Math.round(1.25*(Math.max(0,Number(capacity)||0))+1100);
  const arenaAllocation = capacity => [Math.round(capacity*0.40),Math.round(capacity*0.125),Math.round(capacity*0.45),Math.round(capacity*0.025)];
  const arenaPlan = (current,target,firstEver='unknown',overrides=null) => {
    const base = overrides || arenaAllocation(target);
    const final = base.map((value,i)=>Math.max(current[i],Math.round(Number(value)||0)));
    const added = final.map((value,i)=>value-current[i]);
    const costs = [added[0]*125,added[1]*125,added[2]*125,added[3]*675];
    let constructionBase = 165000;
    if(current[2]===0&&added[2]>0) constructionBase += 330000;
    if(firstEver==='yes') constructionBase -= 300000;
    const newSeats=added.reduce((a,b)=>a+b,0), totalCost=newSeats>0?Math.max(0,costs.reduce((a,b)=>a+b,0)+constructionBase):0;
    const finalCapacity=final.reduce((a,b)=>a+b,0), maxTicketIncome=20*(final[0]+final[2])+15*final[1]+100*final[3];
    return {final,added,costs,constructionBase,newSeats,finalCapacity,totalCost,minFans:Math.round(finalCapacity/17),constructionDays:Math.round(newSeats/300),maxTicketIncome,paybackHomeGames:maxTicketIncome>0?Math.round(totalCost/maxTicketIncome):null};
  };
  window.BasketsimToolsCalc={number,eur,sponsors,agents,cheerleaders,arenaAllocation,arenaPlan};
})();
